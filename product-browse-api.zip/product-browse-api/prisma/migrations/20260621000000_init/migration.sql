-- CreateTable
CREATE TABLE "products" (
    "id" BIGSERIAL NOT NULL,
    "name" VARCHAR(255) NOT NULL,
    "category" VARCHAR(100) NOT NULL,
    "price" DECIMAL(10,2) NOT NULL,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "products_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
-- Supports the default keyset-paginated browse query:
--   ORDER BY updated_at DESC, id DESC
--   WHERE (updated_at, id) < (cursor.updated_at, cursor.id)
CREATE INDEX "idx_products_updated_at_id" ON "products"("updated_at" DESC, "id" DESC);

-- CreateIndex
-- Supports category-filtered keyset pagination. "category" leads the
-- index so Postgres can seek to the matching subset, then walk it in
-- the same (updated_at DESC, id DESC) order the API guarantees.
CREATE INDEX "idx_products_category_updated_at_id" ON "products"("category" ASC, "updated_at" DESC, "id" DESC);

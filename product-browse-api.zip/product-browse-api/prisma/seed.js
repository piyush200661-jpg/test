require('dotenv').config();
const { PrismaClient } = require('@prisma/client');
const { faker } = require('@faker-js/faker');

const prisma = new PrismaClient();

const TOTAL_PRODUCTS = Number(process.env.SEED_TOTAL || 200000);
const BATCH_SIZE = Number(process.env.SEED_BATCH_SIZE || 5000);

// A fixed, realistic category list (rather than fully random strings)
// so the category-filter index has meaningful, repeated values to
// demonstrate selective index scans against.
const CATEGORIES = [
  'Electronics',
  'Home & Kitchen',
  'Books',
  'Clothing',
  'Sports & Outdoors',
  'Toys & Games',
  'Beauty & Personal Care',
  'Automotive',
  'Garden & Tools',
  'Health & Household',
  'Office Products',
  'Pet Supplies',
  'Grocery',
  'Jewelry',
  'Music & Instruments',
];

const TWO_YEARS_MS = 2 * 365 * 24 * 60 * 60 * 1000;

function randomCreatedAt() {
  const now = Date.now();
  return new Date(now - TWO_YEARS_MS + Math.random() * TWO_YEARS_MS);
}

// updated_at is always >= created_at, mirroring how real records behave.
function randomUpdatedAt(createdAt) {
  const now = Date.now();
  return new Date(createdAt.getTime() + Math.random() * (now - createdAt.getTime()));
}

function buildBatch(size) {
  const batch = new Array(size);
  for (let i = 0; i < size; i += 1) {
    const createdAt = randomCreatedAt();
    batch[i] = {
      name: faker.commerce.productName(),
      category: CATEGORIES[Math.floor(Math.random() * CATEGORIES.length)],
      price: Number(faker.commerce.price({ min: 1, max: 5000, dec: 2 })),
      createdAt,
      updatedAt: randomUpdatedAt(createdAt),
    };
  }
  return batch;
}

/**
 * Seeds the database in batches rather than one row at a time.
 *
 * `prisma.product.createMany()` compiles each batch into a single
 * multi-row `INSERT ... VALUES (...), (...), ...` statement. That
 * means one round trip and one transaction per 5,000-10,000 rows
 * instead of 200,000 individual round trips -- the difference between
 * a seed that finishes in seconds/minutes and one that takes hours.
 */
async function seed() {
  console.log(`Seeding ${TOTAL_PRODUCTS} products in batches of ${BATCH_SIZE}...`);
  console.time('seed');

  let inserted = 0;
  while (inserted < TOTAL_PRODUCTS) {
    const currentBatchSize = Math.min(BATCH_SIZE, TOTAL_PRODUCTS - inserted);
    const batch = buildBatch(currentBatchSize);

    await prisma.product.createMany({ data: batch });

    inserted += currentBatchSize;
    console.log(`  inserted ${inserted}/${TOTAL_PRODUCTS}`);
  }

  console.timeEnd('seed');
  console.log('Seed complete.');
}

seed()
  .catch((err) => {
    console.error('Seed failed:', err);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });

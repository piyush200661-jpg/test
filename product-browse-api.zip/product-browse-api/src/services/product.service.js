const { Prisma } = require('@prisma/client');
const { prisma } = require('./prisma.service');

/**
 * Fetches one page of products using keyset (cursor) pagination,
 * frozen to a snapshot point in time.
 *
 * Why keyset instead of OFFSET:
 *   `OFFSET n` forces Postgres to walk and discard the first n matching
 *   rows on every single request -- on a 200k+ row table, page 5,000
 *   would get progressively slower as n grows (O(n) per request). The
 *   keyset predicate below (`(updated_at, id) < (cursor)`) lets
 *   Postgres seek directly to the right starting point using the
 *   composite index, making every page equally fast: O(limit) no
 *   matter how deep into the result set the cursor is.
 *
 * Why the +1 "peek" row:
 *   We ask for `limit + 1` rows. If the extra row comes back, we know
 *   a next page exists -- without running a separate, expensive
 *   COUNT(*) over the (possibly category-filtered) table just to
 *   compute "has more".
 *
 * Why the snapshot_time freeze:
 *   Every query in a browsing session is bounded by
 *   `updated_at <= snapshot_time`. Without this, a product updated (or
 *   inserted with a fresh updated_at) after the user started browsing
 *   could shift positions in the DESC-ordered list and either be shown
 *   twice (duplicate) or skipped entirely (missing) across pages. By
 *   pinning every page of a session to the same snapshot boundary, the
 *   result set a client walks through is logically frozen even while
 *   the underlying table keeps changing.
 */
async function getProducts({ limit, category, cursor, snapshotTime }) {
  const resolvedSnapshotTime = snapshotTime ?? new Date();

  const conditions = [Prisma.sql`updated_at <= ${resolvedSnapshotTime}`];

  if (category) {
    conditions.push(Prisma.sql`category = ${category}`);
  }

  if (cursor) {
    conditions.push(Prisma.sql`(updated_at, id) < (${cursor.updatedAt}, ${cursor.id})`);
  }

  const whereClause = Prisma.join(conditions, ' AND ');

  const rows = await prisma.$queryRaw`
    SELECT
      id,
      name,
      category,
      price,
      created_at AS "createdAt",
      updated_at AS "updatedAt"
    FROM products
    WHERE ${whereClause}
    ORDER BY updated_at DESC, id DESC
    LIMIT ${limit + 1}
  `;

  const hasMore = rows.length > limit;
  const items = hasMore ? rows.slice(0, limit) : rows;

  return { items, hasMore, snapshotTime: resolvedSnapshotTime };
}

module.exports = { getProducts };

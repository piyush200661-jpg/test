const { PrismaClient } = require('@prisma/client');

/**
 * A single, shared PrismaClient instance is reused for the lifetime of
 * the process. Instantiating a new PrismaClient per request would open
 * a fresh connection pool each time and quickly exhaust Postgres's
 * max_connections under load -- Prisma is explicitly designed to be
 * used as a long-lived singleton with its own internal pool instead.
 */
const prisma = new PrismaClient({
  log: process.env.NODE_ENV === 'development' ? ['warn', 'error'] : ['error'],
});

async function disconnectPrisma() {
  await prisma.$disconnect();
}

module.exports = { prisma, disconnectPrisma };

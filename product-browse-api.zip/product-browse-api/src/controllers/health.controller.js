const { prisma } = require('../services/prisma.service');

/**
 * GET /health
 *
 * Confirms both the API process and its database connection are up.
 * A lightweight `SELECT 1` is enough to verify connectivity without
 * touching the products table.
 */
async function getHealth(req, res) {
  await prisma.$queryRaw`SELECT 1`;
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
}

module.exports = { getHealth };

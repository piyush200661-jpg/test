const productService = require('../services/product.service');
const { encodeCursor } = require('../utils/cursor');
const { serializeProduct } = require('../utils/serialize');

/**
 * GET /products
 *
 * Returns one page of products ordered newest-first (updated_at DESC,
 * id DESC), using keyset pagination and a frozen snapshot_time so a
 * client paging through results never sees duplicates or gaps caused
 * by concurrent writes.
 */
async function listProducts(req, res) {
  const { limit, category, cursor, snapshotTime } = req.validatedQuery;

  const { items, hasMore, snapshotTime: resolvedSnapshotTime } = await productService.getProducts({
    limit,
    category,
    cursor,
    snapshotTime,
  });

  const lastItem = items[items.length - 1];
  const nextCursor = hasMore && lastItem
    ? encodeCursor({ updatedAt: lastItem.updatedAt, id: lastItem.id })
    : null;

  res.json({
    items: items.map(serializeProduct),
    next_cursor: nextCursor,
    snapshot_time: resolvedSnapshotTime.toISOString(),
  });
}

module.exports = { listProducts };

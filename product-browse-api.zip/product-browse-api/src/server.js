const app = require('./app');
const { disconnectPrisma } = require('./services/prisma.service');

const PORT = process.env.PORT || 3000;

const server = app.listen(PORT, () => {
  console.log(`product-browse-api listening on port ${PORT}`);
});

/**
 * Graceful shutdown: stop accepting new connections, let in-flight
 * requests finish, then close the Prisma connection pool cleanly.
 * This matters for zero-downtime deploys on platforms like Render,
 * which send SIGTERM before killing the process.
 */
async function shutdown(signal) {
  console.log(`Received ${signal}, shutting down gracefully...`);
  server.close(async () => {
    await disconnectPrisma();
    process.exit(0);
  });
}

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));

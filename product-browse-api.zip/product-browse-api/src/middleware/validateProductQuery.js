const { AppError } = require('../utils/errors');
const { decodeCursor } = require('../utils/cursor');

const DEFAULT_LIMIT = 20;
const MAX_LIMIT = 100;

function parseLimit(raw) {
  if (raw === undefined) return DEFAULT_LIMIT;

  const value = Number(raw);
  if (!Number.isInteger(value) || value < 1 || value > MAX_LIMIT) {
    throw new AppError(`limit must be an integer between 1 and ${MAX_LIMIT}`, 400, 'INVALID_LIMIT');
  }
  return value;
}

function parseCategory(raw) {
  if (raw === undefined || raw === '') return undefined;

  if (typeof raw !== 'string' || raw.length > 100) {
    throw new AppError('category must be a non-empty string of at most 100 characters', 400, 'INVALID_CATEGORY');
  }
  return raw;
}

function parseSnapshotTime(raw) {
  if (raw === undefined) return undefined;

  const date = new Date(raw);
  if (Number.isNaN(date.getTime())) {
    throw new AppError('snapshot_time must be a valid ISO 8601 timestamp', 400, 'INVALID_SNAPSHOT_TIME');
  }
  return date;
}

/**
 * Validates and normalizes every /products query parameter in one
 * place. Controllers and services only ever see clean, typed values
 * (`req.validatedQuery`) and never need to re-validate raw input.
 */
function validateProductQuery(req, res, next) {
  try {
    const limit = parseLimit(req.query.limit);
    const category = parseCategory(req.query.category);
    const snapshotTime = parseSnapshotTime(req.query.snapshot_time);
    const cursor = req.query.cursor ? decodeCursor(req.query.cursor) : undefined;

    if (cursor && !snapshotTime) {
      // A cursor without its originating snapshot_time would let the
      // browsing session drift onto live, ever-changing data instead
      // of the frozen view the client started with -- reject it early
      // rather than silently producing duplicates/missing rows later.
      throw new AppError(
        'snapshot_time is required whenever a cursor is provided',
        400,
        'MISSING_SNAPSHOT_TIME',
      );
    }

    req.validatedQuery = { limit, category, cursor, snapshotTime };
    next();
  } catch (err) {
    next(err);
  }
}

module.exports = validateProductQuery;

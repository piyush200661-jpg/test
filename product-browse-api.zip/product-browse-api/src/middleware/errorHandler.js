const { AppError } = require('../utils/errors');

/**
 * Centralized error handler. Every controller can `throw` an AppError
 * (or pass any error to `next`) and trust that the HTTP response shape
 * stays consistent across the whole API, instead of each route
 * formatting its own error JSON.
 */
// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  if (err instanceof AppError) {
    return res.status(err.statusCode).json({
      error: { message: err.message, code: err.code },
    });
  }

  console.error('Unexpected error:', err);
  return res.status(500).json({
    error: { message: 'Internal server error', code: 'INTERNAL_ERROR' },
  });
}

module.exports = errorHandler;

require('dotenv').config();

const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const morgan = require('morgan');

const productRoutes = require('./routes/product.routes');
const healthRoutes = require('./routes/health.routes');
const notFoundHandler = require('./middleware/notFoundHandler');
const errorHandler = require('./middleware/errorHandler');

const app = express();

app.use(helmet());
app.use(cors());
app.use(express.json());

if (process.env.NODE_ENV !== 'test') {
  app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));
}

app.use('/products', productRoutes);
app.use('/health', healthRoutes);

// Order matters: 404 handler catches unmatched routes, error handler
// must be registered last so Express treats it as the error middleware.
app.use(notFoundHandler);
app.use(errorHandler);

module.exports = app;

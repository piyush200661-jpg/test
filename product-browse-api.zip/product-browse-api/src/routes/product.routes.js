const express = require('express');
const { listProducts } = require('../controllers/product.controller');
const validateProductQuery = require('../middleware/validateProductQuery');
const asyncHandler = require('../utils/asyncHandler');

const router = express.Router();

router.get('/', validateProductQuery, asyncHandler(listProducts));

module.exports = router;

/**
 * Operational error type used throughout the app for predictable,
 * client-facing failures (bad input, not found, etc). Keeping a single
 * error shape lets the centralized error handler respond consistently
 * without inspecting error internals on a case-by-case basis.
 */
class AppError extends Error {
  constructor(message, statusCode = 400, code = 'BAD_REQUEST') {
    super(message);
    this.name = 'AppError';
    this.statusCode = statusCode;
    this.code = code;
  }
}

module.exports = { AppError };

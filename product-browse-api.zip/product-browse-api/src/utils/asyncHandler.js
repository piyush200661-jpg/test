/**
 * Wraps an async Express route handler so that a rejected promise is
 * forwarded to `next(err)` instead of crashing the process or hanging
 * the request. Without this, every controller would need its own
 * try/catch boilerplate.
 */
function asyncHandler(fn) {
  return function wrapped(req, res, next) {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}

module.exports = asyncHandler;

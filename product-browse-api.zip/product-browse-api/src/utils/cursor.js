const { AppError } = require('./errors');

/**
 * Cursors are opaque, base64url-encoded JSON tokens shaped like:
 *   { "updated_at": "2026-06-01T12:00:00.000Z", "id": "184213" }
 *
 * Encoding the cursor (rather than exposing raw `updated_at`/`id`
 * query params) keeps the public API stable if the internal sort key
 * ever changes, and stops clients from hand-crafting arbitrary keyset
 * values.
 */
function encodeCursor({ updatedAt, id }) {
  const payload = JSON.stringify({
    updated_at: updatedAt.toISOString(),
    id: id.toString(),
  });
  return Buffer.from(payload, 'utf8').toString('base64url');
}

function decodeCursor(raw) {
  let parsed;

  try {
    const json = Buffer.from(raw, 'base64url').toString('utf8');
    parsed = JSON.parse(json);
  } catch (err) {
    throw new AppError('cursor is not a valid base64url-encoded JSON token', 400, 'INVALID_CURSOR');
  }

  if (!parsed || typeof parsed.updated_at !== 'string' || parsed.id === undefined || parsed.id === null) {
    throw new AppError('cursor is missing required fields (updated_at, id)', 400, 'INVALID_CURSOR');
  }

  const updatedAt = new Date(parsed.updated_at);
  if (Number.isNaN(updatedAt.getTime())) {
    throw new AppError('cursor.updated_at is not a valid timestamp', 400, 'INVALID_CURSOR');
  }

  let id;
  try {
    id = BigInt(parsed.id);
  } catch (err) {
    throw new AppError('cursor.id is not a valid integer', 400, 'INVALID_CURSOR');
  }

  return { updatedAt, id };
}

module.exports = { encodeCursor, decodeCursor };

/**
 * Converts a Product row (as returned by Prisma) into a JSON-safe
 * plain object. `id` comes back as a JS BigInt and `price` as a
 * Prisma Decimal -- neither survives JSON.stringify on its own, so we
 * convert them explicitly here rather than monkey-patching
 * BigInt.prototype.toJSON globally (which would silently affect
 * unrelated code).
 */
function serializeProduct(product) {
  return {
    id: product.id.toString(),
    name: product.name,
    category: product.category,
    price: Number(product.price),
    created_at: product.createdAt.toISOString(),
    updated_at: product.updatedAt.toISOString(),
  };
}

module.exports = { serializeProduct };

# Product Browse API

A production-quality backend for browsing a catalog of 200,000+ products with **fast, OFFSET-free pagination**, **category filtering**, and **snapshot-consistent results** (no duplicates, no missing records, even while the table is being written to concurrently).

Built with Node.js, Express, PostgreSQL, and Prisma.

---

## Table of Contents

1. [Project Structure](#project-structure)
2. [Setup Instructions](#setup-instructions)
3. [Database Setup](#database-setup)
4. [Environment Variables](#environment-variables)
5. [Seeding 200,000 Products](#seeding-200000-products)
6. [Running the Server](#running-the-server)
7. [API Reference & Examples](#api-reference--examples)
8. [Pagination Design (Deep Dive)](#pagination-design-deep-dive)
9. [Why Cursor Pagination Over OFFSET](#why-cursor-pagination-over-offset)
10. [Snapshot Consistency](#snapshot-consistency)
11. [Database Indexes](#database-indexes)
12. [Performance Considerations](#performance-considerations)
13. [Deployment: Render + Neon](#deployment-render--neon)

---

## Project Structure

```
product-browse-api/
├── src/
│   ├── controllers/        # Thin HTTP layer: parse req, call service, shape res
│   │   ├── product.controller.js
│   │   └── health.controller.js
│   ├── routes/              # Express route wiring
│   │   ├── product.routes.js
│   │   └── health.routes.js
│   ├── services/            # Business logic + all database access
│   │   ├── product.service.js
│   │   └── prisma.service.js
│   ├── middleware/          # Validation + centralized error handling
│   │   ├── validateProductQuery.js
│   │   ├── errorHandler.js
│   │   └── notFoundHandler.js
│   ├── utils/                # Cursor encode/decode, serialization, error types
│   │   ├── cursor.js
│   │   ├── serialize.js
│   │   ├── errors.js
│   │   └── asyncHandler.js
│   ├── app.js                # Express app: middleware + routes (no listen())
│   └── server.js             # Process entrypoint: listen() + graceful shutdown
├── prisma/
│   ├── schema.prisma          # Product model + indexes
│   ├── seed.js                 # Bulk seed script (200k products)
│   └── migrations/             # SQL migration history
├── Dockerfile
├── docker-compose.yml
├── .env.example
└── package.json
```

**Why this layering?** Controllers never talk to Prisma directly — they call a service. This means the pagination/snapshot logic in `product.service.js` is testable in isolation, and swapping the HTTP framework later wouldn't touch the data-access code at all.

---

## Setup Instructions

### Prerequisites

- Node.js ≥ 18
- Docker + Docker Compose (recommended), **or** a local/remote PostgreSQL 14+ instance

### Quick start (Docker, recommended)

```bash
git clone <this-repo>
cd product-browse-api
cp .env.example .env

# Builds the API image, starts Postgres, runs migrations, starts the API
docker compose up --build
```

The API is now on `http://localhost:3000`. Skip to [Seeding](#seeding-200000-products) to load data — the seed script runs on your host machine (or via `docker compose exec`) against the containerized database.

### Manual setup (no Docker)

```bash
git clone <this-repo>
cd product-browse-api
npm install                  # also runs `prisma generate` via postinstall
cp .env.example .env         # then edit DATABASE_URL to point at your Postgres

npm run prisma:migrate:deploy   # apply migrations (creates table + indexes)
npm run seed                     # load 200,000 products
npm run dev                      # start the API with auto-reload
```

---

## Database Setup

This project uses Prisma Migrate, so the schema and both required indexes are version-controlled SQL, not something you create by hand.

```bash
# Create the database (if it doesn't already exist), then apply all
# migrations in prisma/migrations/.
npm run prisma:migrate:deploy
```

This creates the `products` table plus the two composite indexes described in [Database Indexes](#database-indexes). If you ever modify `prisma/schema.prisma`, generate a new migration locally with:

```bash
npm run prisma:migrate:dev -- --name <change_description>
```

---

## Environment Variables

Defined in `.env` (see `.env.example`):

| Variable          | Description                                              | Example                                                              |
|-------------------|------------------------------------------------------------|-----------------------------------------------------------------------|
| `DATABASE_URL`    | Postgres connection string used by Prisma                | `postgresql://postgres:postgres@localhost:5432/products_db?schema=public` |
| `PORT`            | Port the Express server listens on                        | `3000`                                                                 |
| `NODE_ENV`        | `development` \| `production` \| `test`                  | `development`                                                         |
| `SEED_TOTAL`      | Number of products the seed script generates              | `200000`                                                               |
| `SEED_BATCH_SIZE` | Rows per bulk insert batch (keep between 5,000–10,000)    | `5000`                                                                 |

---

## Seeding 200,000 Products

```bash
npm run seed
```

Or, with custom volume/batch size:

```bash
SEED_TOTAL=500000 SEED_BATCH_SIZE=10000 npm run seed
```

Inside Docker:

```bash
docker compose exec api npm run seed
```

The script (`prisma/seed.js`) builds batches of 5,000–10,000 products in memory and inserts each batch with a single `prisma.product.createMany()` call, which compiles to **one multi-row `INSERT ... VALUES (...), (...), ...` statement per batch** — one round trip per 5,000–10,000 rows instead of 200,000 individual round trips. It never inserts row-by-row.

Each product gets a random category from a fixed 15-category list, a random price, and randomized `created_at`/`updated_at` timestamps (with `updated_at >= created_at`) spread across the last two years, so the dataset realistically exercises both indexes.

---

## Running the Server

```bash
npm run dev      # development, auto-restart on file change (nodemon)
npm start        # production
```

Health check:

```bash
curl http://localhost:3000/health
# { "status": "ok", "timestamp": "2026-06-21T10:00:00.000Z" }
```

---

## API Reference & Examples

### `GET /products`

| Param           | Type   | Required | Description                                                                 |
|-----------------|--------|----------|-------------------------------------------------------------------------------|
| `limit`         | int    | no       | Page size, 1–100. Defaults to 20.                                              |
| `category`      | string | no       | Filter to a single category (exact match).                                    |
| `cursor`        | string | no       | Opaque cursor from a previous response's `next_cursor`. Omit on the first page. |
| `snapshot_time` | string | required if `cursor` is set | ISO 8601 timestamp from the first page's response. Freezes the browsing session. |

**Response shape:**

```json
{
  "items": [
    {
      "id": "184213",
      "name": "Ergonomic Steel Chair",
      "category": "Office Products",
      "price": 129.99,
      "created_at": "2025-11-02T08:15:00.000Z",
      "updated_at": "2026-06-01T12:00:00.000Z"
    }
  ],
  "next_cursor": "eyJ1cGRhdGVkX2F0IjoiMjAyNi0wNi0wMVQxMjowMDowMC4wMDBaIiwiaWQiOiIxODQyMTMifQ",
  "snapshot_time": "2026-06-21T10:00:00.000Z"
}
```

`next_cursor` is `null` on the last page.

#### Example: first page

```bash
curl "http://localhost:3000/products?limit=20"
```

The response includes `snapshot_time`. **Save it.**

#### Example: next page

```bash
curl "http://localhost:3000/products?limit=20&cursor=<next_cursor>&snapshot_time=<snapshot_time>"
```

#### Example: category-filtered browsing

```bash
curl "http://localhost:3000/products?limit=20&category=Electronics"
# then, for subsequent pages:
curl "http://localhost:3000/products?limit=20&category=Electronics&cursor=<next_cursor>&snapshot_time=<snapshot_time>"
```

### `GET /health`

Returns `{ "status": "ok", "timestamp": "..." }` after verifying the database connection with `SELECT 1`. Returns `500` if the database is unreachable.

---

## Pagination Design (Deep Dive)

Products are always ordered **`updated_at DESC, id DESC`** — newest-first, with `id` as a tie-breaker for rows sharing the same `updated_at` (which is common in bulk-seeded or bulk-updated data).

A cursor is a base64url-encoded JSON token:

```json
{ "updated_at": "2026-06-01T12:00:00.000Z", "id": "184213" }
```

To fetch the next page, the service issues:

```sql
SELECT id, name, category, price, created_at, updated_at
FROM products
WHERE updated_at <= $snapshot_time
  [AND category = $category]
  AND (updated_at, id) < ($cursor.updated_at, $cursor.id)
ORDER BY updated_at DESC, id DESC
LIMIT $limit + 1;
```

The row-value comparison `(updated_at, id) < (cursor.updated_at, cursor.id)` is exactly equivalent to:

```
updated_at < cursor.updated_at
OR (updated_at = cursor.updated_at AND id < cursor.id)
```

— but expressed as a single tuple comparison that Postgres's planner matches directly against the composite index, letting it **seek** to the right starting point instead of scanning.

The query asks for `limit + 1` rows. If the extra row comes back, there's a next page, and the **last row of the requested page** (not the extra row) becomes the next cursor. This avoids running a separate `COUNT(*)` just to know whether more data exists — expensive on a 200k+ row table.

---

## Why Cursor Pagination Over OFFSET

`OFFSET n LIMIT m` requires Postgres to **scan and discard the first `n` matching rows on every request**, even though the client only wants rows `n` through `n+m`. As `n` grows, every page gets slower — page 1 might take a few milliseconds, but page 5,000 of a 200k-row table means walking and throwing away tens of thousands of rows first. This is O(n) per request.

Keyset (cursor) pagination is **O(limit) per request, independent of how deep the cursor is**, because the composite index lets Postgres jump straight to `(updated_at, id) < cursor` using an index range scan — no rows are scanned and discarded.

OFFSET pagination also breaks under concurrent writes: if a row is inserted or deleted while a user pages through results, every subsequent "page N" can shift, causing the same product to reappear or another to be skipped. Keyset pagination sidesteps this structurally — each page is defined relative to the last row actually seen, not a positional row count — and combined with snapshot consistency (next section), it's also immune to concurrent writes during the session.

---

## Snapshot Consistency

**Problem:** Without a snapshot boundary, a product updated (or newly inserted with a fresh `updated_at`) while a user is mid-browse could jump to the top of the DESC-ordered list. Depending on timing, the user could see that product **twice** (once on an earlier page, once again after it moved) or **never** (it jumped past the page boundary they already passed).

**Solution:** The first request (no `cursor`) generates `snapshot_time = now()` and returns it in the response. Every subsequent request in that browsing session must echo that same `snapshot_time` back, and **every query — first page or not — is bounded by**:

```sql
WHERE updated_at <= $snapshot_time
```

This freezes the logical result set: rows with `updated_at > snapshot_time` (new inserts, or edits to existing rows that happened after the snapshot) are excluded from every page of that session, so the ordered list a client walks through never shifts underneath them. New activity becomes visible the next time the client starts a fresh session (omits `cursor`/`snapshot_time` and gets a new snapshot).

This is enforced in code, not left to convention: `validateProductQuery` middleware **rejects any request that includes a `cursor` without a `snapshot_time`** (`400 MISSING_SNAPSHOT_TIME`), so it's impossible to accidentally page through live, drifting data.

---

## Database Indexes

```prisma
@@index([updatedAt(sort: Desc), id(sort: Desc)], name: "idx_products_updated_at_id")
@@index([category, updatedAt(sort: Desc), id(sort: Desc)], name: "idx_products_category_updated_at_id")
```

### 1. `idx_products_updated_at_id` on `(updated_at DESC, id DESC)`

Backs the **default, unfiltered browse query**. Because the index is physically stored in the same order the API always queries in (`ORDER BY updated_at DESC, id DESC`), Postgres can:
- Satisfy the `ORDER BY` with zero sort step (the index is already sorted).
- Satisfy the keyset predicate `(updated_at, id) < (cursor...)` as an index range scan, seeking directly to the cursor position.

Without this index, every page request would require a full sequential scan + sort of the entire `products` table.

### 2. `idx_products_category_updated_at_id` on `(category, updated_at DESC, id DESC)`

Backs **category-filtered browsing**. `category` leads the index, so for a query like `WHERE category = 'Electronics' AND ...`, Postgres seeks straight to the `'Electronics'` slice of the index — it never touches rows from other categories. Within that slice, rows are already sorted by `(updated_at DESC, id DESC)`, so the same keyset predicate and `ORDER BY` are satisfied for free, just like index #1, but scoped to the filtered subset.

This single composite index serves the filter, the sort, and the pagination cursor all from one index scan — no separate sort step, no fallback to the unfiltered index plus a manual re-sort.

---

## Performance Considerations

- **No OFFSET, anywhere.** Every paginated query is a keyset seek against a composite index — page 1 and page 10,000 cost the same.
- **`LIMIT + 1` instead of `COUNT(*)`** to detect a next page, avoiding an expensive aggregate scan over a 200k+ (optionally filtered) row set on every request.
- **Composite indexes pre-sorted in query order** (`DESC, DESC`) mean Postgres never performs an in-memory sort for these queries, regardless of table size.
- **Bulk seeding** via batched `createMany()` (5,000–10,000 rows per multi-row `INSERT`) rather than row-by-row inserts — orders of magnitude fewer round trips.
- **A single shared `PrismaClient`** (one connection pool) is reused for the process lifetime instead of being instantiated per request, which would otherwise exhaust Postgres's `max_connections` under load.
- **Cursor values are opaque tokens**, not raw query params — this keeps `(updated_at, id)` as an implementation detail, so the index strategy can evolve without breaking API consumers.
- **`BIGSERIAL` id** avoids the 32-bit `INTEGER` overflow ceiling (~2.1 billion) and gives a stable, always-increasing tie-breaker for rows with identical `updated_at`.

---

## Deployment: Render + Neon

This setup uses [Neon](https://neon.tech) for managed serverless Postgres and [Render](https://render.com) for the API.

### 1. Provision the database on Neon

1. Create a Neon project and database.
2. Copy the connection string from the Neon dashboard. It looks like:
   ```
   postgresql://<user>:<password>@<host>/<dbname>?sslmode=require
   ```
3. Append `&schema=public` if you want to be explicit, though Prisma defaults to `public`.

### 2. Deploy the API on Render

1. Push this repository to GitHub.
2. In Render, create a **new Web Service** from the repo.
3. Configure:
   - **Environment**: Docker (Render will use the included `Dockerfile`).
   - **Environment Variables**:
     - `DATABASE_URL` → the Neon connection string from step 1.
     - `NODE_ENV` → `production`.
   - Render automatically injects `PORT` — the app already reads `process.env.PORT`.
4. Deploy. The Dockerfile's `CMD` runs `prisma migrate deploy` automatically before starting the server, so the schema and indexes are created on first boot — no manual migration step needed.

### 3. Seed the production database

Run the seed script once against the Neon database, either:

- **Locally**, by pointing your `.env`'s `DATABASE_URL` at the Neon connection string and running `npm run seed`, or
- **From a Render Shell** (Render dashboard → your service → "Shell"): `npm run seed`.

> Neon's serverless compute can auto-suspend after inactivity; the first request after idling may be slower while it resumes. This doesn't affect query correctness, only initial latency.

### 4. Verify

```bash
curl https://<your-render-service>.onrender.com/health
curl "https://<your-render-service>.onrender.com/products?limit=10"
```
